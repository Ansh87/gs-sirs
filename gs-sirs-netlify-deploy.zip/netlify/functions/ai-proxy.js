// GS-SIRS AI Assistant proxy — Gemini backend
// Forwards chat requests from the browser to Google's Gemini API.
// The API key is held server-side here; browsers can't call Gemini directly (CORS).

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers, body: '' };
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return {
    statusCode: 500, headers,
    body: JSON.stringify({ error: 'Server not configured: GEMINI_API_KEY missing from environment variables.' })
  };

  let payload;
  try { payload = JSON.parse(event.body || '{}'); }
  catch (e) { return { statusCode: 400, headers, body: JSON.stringify({ error: 'Invalid JSON' }) }; }

  const { system, messages } = payload;
  if (!Array.isArray(messages) || messages.length === 0)
    return { statusCode: 400, headers, body: JSON.stringify({ error: 'messages array is required' }) };

  // Convert Anthropic-style {role, content} messages to Gemini's {role, parts:[{text}]} format
  // Gemini uses "model" instead of "assistant" for the AI role
  const geminiContents = messages.map(m => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.content }]
  }));

  const model = 'gemini-2.5-flash';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

  try {
    const resp = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        system_instruction: system ? { parts: [{ text: system }] } : undefined,
        contents: geminiContents,
        generationConfig: { maxOutputTokens: 1000, temperature: 0.7 }
      })
    });

    const data = await resp.json();

    if (!resp.ok) return {
      statusCode: resp.status, headers,
      body: JSON.stringify({ error: data?.error?.message || 'Gemini API error', detail: data })
    };

    // Extract text from Gemini's response and return in Anthropic-compatible shape
    // so the frontend code doesn't need to change
    const text = data?.candidates?.[0]?.content?.parts?.map(p => p.text).join('') || '';
    return {
      statusCode: 200, headers,
      body: JSON.stringify({ content: [{ type: 'text', text }] })
    };
  } catch (e) {
    return { statusCode: 502, headers, body: JSON.stringify({ error: 'Failed to reach Gemini API', detail: String(e) }) };
  }
};
